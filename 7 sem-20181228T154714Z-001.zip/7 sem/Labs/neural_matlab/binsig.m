function y = binsig (x)
y=1/(1+exp(-x));
end