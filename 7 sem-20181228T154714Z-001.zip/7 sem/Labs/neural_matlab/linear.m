x=[-1 -1 1 1];
y=[-1 1 -1 1];
scatter(x,y,'filled');
plot([-1 0],[0,-1]);
xlim([-2 2]);
ylim([-2 2]);