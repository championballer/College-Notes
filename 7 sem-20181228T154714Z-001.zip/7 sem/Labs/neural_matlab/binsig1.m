function y=binsig1(x)
y=binsig(x)*(1-binsig(x));
end